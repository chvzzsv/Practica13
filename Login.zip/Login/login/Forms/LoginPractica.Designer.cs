﻿namespace login.Forms
{
    partial class LoginPractica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginPractica));
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            txtUsuario = new TextBox();
            txtPwd = new TextBox();
            label2 = new Label();
            label3 = new Label();
            btnAcceder = new Button();
            linkPwd = new LinkLabel();
            pictureBoxMinimizar = new PictureBox();
            pictureBoxCerrar = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxMinimizar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCerrar).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.MediumBlue;
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 450);
            panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(39, 139);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(159, 161);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(480, 26);
            label1.Name = "label1";
            label1.Size = new Size(110, 46);
            label1.TabIndex = 1;
            label1.Text = "Login";
            // 
            // txtUsuario
            // 
            txtUsuario.Location = new Point(430, 139);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.Size = new Size(202, 27);
            txtUsuario.TabIndex = 2;
            txtUsuario.Text = "USUARIO";
            txtUsuario.Enter += txtUsuario_Enter;
            txtUsuario.Leave += txtUsuario_Leave;
            // 
            // txtPwd
            // 
            txtPwd.Location = new Point(430, 238);
            txtPwd.Name = "txtPwd";
            txtPwd.Size = new Size(202, 27);
            txtPwd.TabIndex = 3;
            txtPwd.Text = "CONTRASEÑA";
            txtPwd.Enter += txtPwd_Enter;
            txtPwd.Leave += txtPwd_Leave;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.ButtonFace;
            label2.Location = new Point(430, 98);
            label2.Name = "label2";
            label2.Size = new Size(84, 28);
            label2.TabIndex = 4;
            label2.Text = "Usuario";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ButtonFace;
            label3.Location = new Point(430, 207);
            label3.Name = "label3";
            label3.Size = new Size(118, 28);
            label3.TabIndex = 5;
            label3.Text = "Contraseña";
            // 
            // btnAcceder
            // 
            btnAcceder.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnAcceder.Location = new Point(480, 337);
            btnAcceder.Name = "btnAcceder";
            btnAcceder.Size = new Size(114, 29);
            btnAcceder.TabIndex = 6;
            btnAcceder.Text = "Iniciar sesión";
            btnAcceder.UseVisualStyleBackColor = true;
            // 
            // linkPwd
            // 
            linkPwd.AutoSize = true;
            linkPwd.Location = new Point(435, 292);
            linkPwd.Name = "linkPwd";
            linkPwd.Size = new Size(197, 20);
            linkPwd.TabIndex = 7;
            linkPwd.TabStop = true;
            linkPwd.Text = "Has olvidado tu contraseña?";
            // 
            // pictureBoxMinimizar
            // 
            pictureBoxMinimizar.Image = (Image)resources.GetObject("pictureBoxMinimizar.Image");
            pictureBoxMinimizar.Location = new Point(674, 12);
            pictureBoxMinimizar.Name = "pictureBoxMinimizar";
            pictureBoxMinimizar.Size = new Size(48, 37);
            pictureBoxMinimizar.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxMinimizar.TabIndex = 8;
            pictureBoxMinimizar.TabStop = false;
            pictureBoxMinimizar.Click += pictureBoxMinimizar_Click;
            // 
            // pictureBoxCerrar
            // 
            pictureBoxCerrar.Image = (Image)resources.GetObject("pictureBoxCerrar.Image");
            pictureBoxCerrar.Location = new Point(740, 12);
            pictureBoxCerrar.Name = "pictureBoxCerrar";
            pictureBoxCerrar.Size = new Size(48, 37);
            pictureBoxCerrar.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxCerrar.TabIndex = 9;
            pictureBoxCerrar.TabStop = false;
            pictureBoxCerrar.Click += pictureBoxCerrar_Click;
            // 
            // LoginPractica
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkRed;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBoxCerrar);
            Controls.Add(pictureBoxMinimizar);
            Controls.Add(linkPwd);
            Controls.Add(btnAcceder);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtPwd);
            Controls.Add(txtUsuario);
            Controls.Add(label1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "LoginPractica";
            Opacity = 0.9D;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "LoginPractica";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxMinimizar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCerrar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private TextBox txtUsuario;
        private TextBox txtPwd;
        private Label label2;
        private Label label3;
        private Button btnAcceder;
        private PictureBox pictureBox1;
        private LinkLabel linkPwd;
        private PictureBox pictureBoxMinimizar;
        private PictureBox pictureBoxCerrar;
    }
}